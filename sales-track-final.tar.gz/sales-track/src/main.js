import { setAdapter, openDb } from './db/db.js';
import { capacitorAdapter } from './db/capacitor.js';
import { ensureDeviceId } from './auth/auth.js';
import { start, lockNow } from './ui/app.js';
import { startSync } from './sync/engine.js';
import { startAutoLock } from './auth/lock.js';
(async () => { setAdapter(capacitorAdapter); await openDb(); await ensureDeviceId(); await start(); startSync(); startAutoLock(lockNow); })();
