// Hands a finished file to the phone: the Android share sheet lets the person save it to Google Drive, Files,
// or send it by WhatsApp or email. (No Google sign-in is built into the app, so nothing is uploaded automatically.)
const b64 = (bytes) => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); return btoa(s); };
export async function shareFile(name, data, mime) {
  const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  try {
    const { Filesystem, Directory } = await import('@capacitor/filesystem'), { Share } = await import('@capacitor/share');
    try { await Filesystem.rmdir({ path: 'exports', directory: Directory.Cache, recursive: true }); } catch { /* none yet */ } // old reports don't linger in cache
    await Filesystem.writeFile({ path: `exports/${name}`, data: b64(bytes), directory: Directory.Cache, recursive: true });
    const { uri } = await Filesystem.getUri({ path: `exports/${name}`, directory: Directory.Cache });
    await Share.share({ title: name, files: [uri], dialogTitle: 'Save or send report' });
  } catch (e) {
    if (/cancel/i.test(String(e?.message))) return 'cancelled';
    if (typeof document === 'undefined' || window.Capacitor?.isNativePlatform?.()) throw e; // on a phone, report the error; in a browser preview, download instead
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: mime })); a.download = name; a.click(); // browser preview fallback
  }
  return 'shared';
}
