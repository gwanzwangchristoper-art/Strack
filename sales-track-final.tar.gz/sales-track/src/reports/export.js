import { audit } from '../db/db.js';
import { currentUser } from '../auth/auth.js';
import { buildReport, allowed } from './data.js';
import { toCSV, toXlsx, toPdf, fileName } from './format.js';

export const FORMATS = { csv: { ext: 'csv', mime: 'text/csv', label: 'CSV' }, xlsx: { ext: 'xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', label: 'Excel' }, pdf: { ext: 'pdf', mime: 'application/pdf', label: 'PDF' } };

// Makes the file for a report that was already built (the screen builds once to preview, then exports).
// Every export is written to the audit log: who took which figures out of the app, and when.
export async function exportBuilt(rep, format) {
  const u = currentUser(), f = FORMATS[format];
  if (!u || !f) throw new Error('Choose CSV, Excel or PDF.');
  if (!allowed(u, rep.key)) throw new Error('Admin permission required.'); // checked again here, not only when the report was built
  const data = format === 'csv' ? toCSV(rep) : format === 'xlsx' ? toXlsx(rep) : toPdf(rep);
  await audit(u.id, 'report_exported', null, { report: rep.title, format: f.label, period: rep.period, rows: rep.rows.length });
  return { name: fileName(rep, f.ext), mime: f.mime, data, rows: rep.rows.length };
}
export async function exportReport(key, range, format) { return exportBuilt(await buildReport(key, range), format); }
