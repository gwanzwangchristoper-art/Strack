import test from 'node:test';
import assert from 'node:assert/strict';
import { unzipSync, strFromU8 } from 'fflate';
import { toCSV, toXlsx, toPdf, fileName } from '../src/reports/format.js';

const rep = (over = {}) => ({ key: 'sales', title: 'Sales report', period: '2026-09-01 to 2026-09-30',
  columns: [{ key: 'name', label: 'Product', kind: 'text' }, { key: 'qty', label: 'Quantity', kind: 'num' }, { key: 'total', label: 'Total (NGN)', kind: 'money' }, { key: 'm', label: 'Margin (%)', kind: 'pct' }],
  rows: [{ name: 'Coca Cola', qty: 3, total: 1500, m: 20.5 }, { name: 'Ọlá "special", pack', qty: 1.5, total: 1234567.891, m: null }, { name: '=HYPERLINK("http://x","click")', qty: 1, total: 5, m: 0 }],
  totals: { name: 'Total', qty: 5.5, total: 1236072.89 }, notes: ['Confirmed sales only.'], meta: { business: 'Chris & Sons <Ltd>', generatedBy: 'Chris', generatedAt: '2026-09-30T10:15:00.000Z' }, ...over });

test('CSV: BOM, CRLF, quoting, numbers stay numbers, formulas defused, totals row', () => {
  const c = toCSV(rep()), lines = c.replace('\uFEFF', '').split('\r\n');
  assert.equal(c.charCodeAt(0), 0xFEFF); assert.equal(lines[0], 'Product,Quantity,Total (NGN),Margin (%)');
  assert.equal(lines[1], 'Coca Cola,3,1500.00,20.5');
  assert.equal(lines[2], '"Ọlá ""special"", pack",1.5,1234567.89,');          // accents kept, quotes doubled, money = plain 2-decimal number
  assert.ok(lines[3].startsWith('"\'=HYPERLINK(""http://x"",""click"")"') || lines[3].startsWith("'=HYPERLINK"));   // leading = neutralised
  assert.equal(lines[4], 'Total,5.5,1236072.89,'); assert.equal(lines.at(-1), '');
});
test('CSV: negative numbers are numbers, but text starting with - or + is defused', () => {
  const c = toCSV(rep({ rows: [{ name: '-5% deal', qty: -3, total: -10, m: null }], totals: null }));
  assert.match(c, /'-5% deal,-3,-10\.00,/);
});
test('Excel: valid package, real numbers, bold total, About sheet, XML-safe text', () => {
  const z = unzipSync(toXlsx(rep())), names = Object.keys(z).sort();
  assert.deepEqual(names, ['[Content_Types].xml', '_rels/.rels', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/workbook.xml', 'xl/worksheets/sheet1.xml', 'xl/worksheets/sheet2.xml']);
  const s1 = strFromU8(z['xl/worksheets/sheet1.xml']), s2 = strFromU8(z['xl/worksheets/sheet2.xml']);
  assert.match(s1, /<c r="B2" s="0"><v>3<\/v><\/c>/) ; assert.match(s1, /<c r="C3" s="3"><v>1234567\.891<\/v><\/c>/);
  assert.match(s1, /Ọlá &quot;special&quot;, pack/); assert.match(s1, /=HYPERLINK/);                      // stored as TEXT, so Excel will not run it
  assert.match(s1, /<c r="A5" t="inlineStr" s="5">/); assert.match(s1, /<autoFilter ref="A1:D4"\/>/);    // filter stops above the total row
  assert.match(s2, /Chris &amp; Sons &lt;Ltd&gt;/);
  assert.match(strFromU8(z['xl/workbook.xml']), /<sheet name="Sales report" sheetId="1"/);
});
test('Excel: column letters past Z and illegal control characters', () => {
  const cols = Array.from({ length: 28 }, (_, i) => ({ key: 'k' + i, label: 'C' + i, kind: 'text' }));
  const z = unzipSync(toXlsx(rep({ columns: cols, rows: [Object.fromEntries(cols.map(c => [c.key, 'a\u0001b']))], totals: null })));
  const s = strFromU8(z['xl/worksheets/sheet1.xml']); assert.match(s, /<c r="AB2"/); assert.doesNotMatch(s, /\u0001/); assert.match(s, /ab/);
});
test('PDF: structure is valid (offsets, page count), text is Latin-only, table paginates', () => {
  const many = Array.from({ length: 120 }, (_, i) => ({ name: `Product ${i} Ọlá ₦`, qty: i, total: i * 10.5, m: 5 }));
  const bytes = toPdf(rep({ rows: many })), s = Buffer.from(bytes).toString('latin1');
  assert.ok(s.startsWith('%PDF-1.4')); assert.ok(s.trimEnd().endsWith('%%EOF'));
  const pages = +/\/Count (\d+)/.exec(s)[1]; assert.ok(pages >= 3); assert.equal((s.match(/\/Type \/Page /g) || []).length, pages);
  const xref = +/startxref\n(\d+)/.exec(s)[1]; assert.equal(s.slice(xref, xref + 4), 'xref');
  const offs = [...s.slice(xref).matchAll(/(\d{10}) 00000 n /g)].map(m => +m[1]);
  offs.forEach((o, i) => assert.equal(s.slice(o, o + 12).startsWith(`${i + 1} 0 obj`), true, 'object ' + (i + 1)));
  [...s.matchAll(/\/Length (\d+) >>\nstream\n/g)].forEach(m => { const start = m.index + m[0].length; assert.equal(s.slice(start + +m[1], start + +m[1] + 10), '\nendstream'); });
  assert.match(s, /Page 1 of \d+/); assert.match(s, /Product 5 Ola N/);                               // Ọ -> O, lowercase á -> a, ₦ -> N
  assert.match(s, /\(Confirmed sales only\.\)/);
});
test('PDF: a huge report is capped with a clear note, and the total row is still shown', () => {
  const big = Array.from({ length: 3000 }, (_, i) => ({ name: 'P' + i, qty: 1, total: 1, m: 1 }));
  const s = Buffer.from(toPdf(rep({ rows: big }), { maxRows: 500 })).toString('latin1');
  assert.match(s, /Showing the first 500 of 3,000 rows/); assert.match(s, /\(Total\)/); assert.doesNotMatch(s, /\(P2999\)/);
});
test('PDF: parentheses and backslashes cannot break the file', () => {
  const s = Buffer.from(toPdf(rep({ rows: [{ name: 'a) Tj (b \\ c', qty: 1, total: 1, m: 1 }], totals: null }))).toString('latin1');
  assert.match(s, /a\\\) Tj \\\(b \\\\ c/);
});
test('file names are safe and say what and when', () => {
  assert.equal(fileName(rep(), 'csv'), 'sales-track_sales-report_2026-09-01_to_2026-09-30.csv');
  assert.equal(fileName(rep({ key: 'inventory', period: 'As at 2026-09-30' }), 'pdf'), 'sales-track_inventory-report_2026-09-30.pdf');
});
